/*
 * File for implementation of the room class
 * CSF Assignment 5
 * Madeline Estey (mestey1@jhu.edu)
 * Owen Reed (oreed2@jhu.edu)
 */
#include <iostream>
#include "guard.h"
#include "message.h"
#include "message_queue.h"
#include "user.h"
#include "room.h"

/*
Room constructor that inits mutex lock for the room.
*/
Room::Room(const std::string &room_name)
  : room_name(room_name) {
  // initialize the mutex
  pthread_mutex_init(&lock, NULL);
}

/*
Room destructor to remove the mutex.
*/
Room::~Room() {
  pthread_mutex_destroy(&lock);
}


/*
Function to add a member to the room. Will be locked by the mutex during all access.
*/
void Room::add_member(User *user) {
  // add User to the room
  if (members.count(user) <= 0) {
    Guard g(lock); //protect access while adding user
    this->members.insert(user);
  }
}

/*
Function to delete a member from the room. Will be locked by the mutex during all access.
*/
void Room::remove_member(User *user) {
  // remove User from the room
  if (members.count(user) > 0) {
    Guard g(lock);//protect access while adding user
    members.erase(members.find(user));
  }
}

/*
Function to send out a message to all recv inside the room. Will lock during iteration to prevent changes in user list.
*/
void Room::broadcast_message(const std::string &sender_username, const std::string &message_text) {
  // send a message to every (receiver) User in the roomm
  Message msg;
  msg.data = strip_text(get_room_name());
  msg.data += ":";
  msg.data += strip_text(sender_username);
  msg.data += ":";
  msg.data += strip_text(message_text);
  msg.tag = "delivery";
  Guard g(lock);
  std::set<User *>::iterator it;
  for (it = members.begin(); it != members.end(); ++it) {
    // Create new message
    if (!((*it)->is_sender)) {
      (*it)->mqueue.enqueue(new Message(msg.tag,msg.data));
    }
  }
  
}

/*
Helper function to strip new line chars from strings.
*/
std::string Room::strip_text(std::string input) {
  size_t pos = (input).find("\n");
  if (pos != std::string::npos) {
    input.erase(pos,input.length());
  }
  pos = (input).find("\r");
  if (pos != std::string::npos) {
    input.erase(pos,input.length());
  }
  return input;
}
