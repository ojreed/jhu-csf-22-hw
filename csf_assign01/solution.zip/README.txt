Maddie Estey and Owen Reed

For the most part we worked on the project together in brody with Maddie taking the lead on the create 
functions the create from hex functions while I worked mostly on the add, subtract and negate for right now. 
Mostly though this division of labor described above is largly symbolic since we both worked on each of the 
functions for the most part. This is also liable to change as we continue to improve our code.