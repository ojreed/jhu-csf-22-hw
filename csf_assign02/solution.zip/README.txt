Madeline (Maddie) Estey and Owen Reed

We worked on most of the functions together in Brody. Owen then worked on fixing our color burring errors and adding bounds
checks. Maddie worked on the unit tests.

