Madeline (Maddie) Estey and Owen Reed

We worked on the functions together in Brody until we at least had a draft of them all. We did some debugging together too but
also did some on our own.

