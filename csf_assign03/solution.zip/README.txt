Madeline (Maddie) Estey and Owen Reed

In the beginning, we worked together in Brody to create the project's general file and class structure. We did some functions together
but then also worked individually on some and worked individually to debug (ex: debugging why our counter amounts were wrong).

One of the biggest challenges we encountered was how to correctly count cycles.

We had most of part 3 of this homework completed by the due date for part 2. All we had to work on after submitting part 2 was input validation and
cleaning up our code in general.