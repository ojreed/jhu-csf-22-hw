Madeline (Maddie) Estey and Owen Reed

In the beginning, we worked together in Brody to create the project's general file and class structure. We did some functions together
but then also worked individually on some and worked individually to debug (ex: debugging why our counter amounts were wrong).