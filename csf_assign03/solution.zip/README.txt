Madeline (Maddie) Estey and Owen Reed

we worked together in brody on mst1 functionality such as the command line parsing and trace file reading