Madeline (Maddie) Estey and Owen Reed

We did a combination of individual and group work. Owen started individually working on sender logic while Maddie individually worked
on the receiver file over Thanksgiving break. We then started meeting up to debug, put code into the functions in connection.cpp, and 
fix small protocol/style issues.
